# RATIO — BRIEF OPERATIVO COMPLETO
> Documento di riferimento per continuare lo sviluppo del sito in qualsiasi sessione futura.
> Per riprendere: carica questo file e di' all'assistente "leggi BRIEF.md e riparti da qui".

---

## 1. IDENTITÀ DEL PROGETTO

| Campo | Valore |
|---|---|
| **Nome prodotto** | RATIO |
| **Tagline** | Decisioni Executive. Senza Errore. |
| **Tipo sito** | Landing page one-page premium dark — BILINGUE IT + EN |
| **Lingue** | Italiano (default) + English |
| **URL live IT** | https://ratioapp.co |
| **URL live EN** | https://ratioapp.co/en_index.html |
| **Email contatto** | decision@ratioapp.co |
| **Sede operativa** | Dubai, UAE |
| **Versione sistema** | v2.4.1 — BUILD 20241114 |

---

## 2. POSIZIONAMENTO E TONO

- **Cos'è RATIO**: sistema di valutazione decisionale per la selezione di candidati in ruoli executive ad alto impatto. NON è recruiting, NON è head hunting, NON è un test automatico.
- **Problema risolto**: il 46% delle selezioni executive fallisce entro 18 mesi. Il bias cognitivo amplifica gli errori (3.2×). Il costo di un'assunzione sbagliata è 4× il costo annuo del ruolo.
- **Tono**: autorevole, senior, implicito. NON promozionale, NON personal branding, NON visibile come agenzia di reclutamento.
- **Percezione desiderata**: sistema + metodo, presenza umana senior esperta, servizio di consulenza premium.
- **Supervisione umana**: "Analisi condotta da mental coach aziendale senior" — elemento chiave da mantenere visibile e autorevole.

---

## 3. STRUTTURA DEL SITO (sezioni in ordine)

### [1] BOOT OVERLAY
- Schermata di avvio animata con logo "RATIO", log di inizializzazione, barra di progresso e status "INIZIALIZZAZIONE..."
- Gestita da `js/main.js` → funzione `initBoot()`

### [2] NAVIGATION (header fisso)
- Logo: immagine `./ratio-logo.png` (R dorata) + badge `SYS v2.4`
- Link: HOME | CHI SIAMO | COME FUNZIONA | OUTPUT | CONTATTI
- Email in navbar: `decision@ratioapp.co`
- Progress bar di scroll in fondo all'header

### [3] HERO (#home)
- **Eyebrow**: "FILTRO DECISIONALE — EXECUTIVE SELECTION" / REL. 2.4.1
- **Headline**: "Assumi senza errore. / Con controllo totale / del rischio."
- **Body**: "Sistema decisionale per la selezione executive. Trasforma valutazioni complesse in decisioni verificabili."
- **Clarify** (italic, bordo sinistro): "Valutiamo candidati per ruoli critici quando la decisione non può essere lasciata all'intuizione."
- **CTA buttons**: "CONTATTACI" (→ #contatti) + "VEDI IL SISTEMA" (→ #come-funziona)
- **Meta chips**: Sistema Operativo (verde) | 3 Slot Rimasti (giallo) | Accesso su Selezione (rosso)
- **Panel destra**: Assessment Preview — REF ASS-2024-0847, posizione COO, metriche 87/74/81/34%, raccomandazione "PROCEDERE — SECONDA FASE OBBLIGATORIA"

### [4] CHI SIAMO / CONTESTO OPERATIVO (#chi-siamo)
- **Eyebrow**: CONTESTO OPERATIVO / MOD.CTX-01
- **Headline**: "Le decisioni sbagliate costano più del talento."
- **Subtext**: "Il problema non è trovare candidati. È scegliere quello giusto quando l'errore è costoso."
- **Context secondary**: "Ogni errore di selezione executive ha un costo strutturale. Non è un problema di persone — è un problema di metodo."
- **Blocco "COS'È RATIO"**: "RATIO non è recruiting. Non è head hunting. Non è un test automatico. È un sistema di valutazione decisionale per scegliere candidati in ruoli ad alto impatto."
- **3 Data Cards**:
  - 01: Errore di Valutazione — 46% tasso mismatch — CRITICO (fonte: Global HR Benchmark 2024)
  - 02: Il Costo del Giudizio — 3.2× amplificazione bias — ATTENZIONE (fonte: Kahneman-derived index 2023)
  - 03: Il Prezzo di un Errore — 4× moltiplicatore costo — CRITICO (fonte: McKinsey Talent Report 2024)

### [5] ARCHITETTURA DEL SISTEMA (#sistema)
- **Eyebrow**: ARCHITETTURA DEL SISTEMA / MOD.SYS-02
- **Headline**: "Non è un processo. È un filtro decisionale."
- **Chips**: MODULI 03 | CRITERI 128+ | ACCURATEZZA 94%
- **3 Moduli**:
  - MOD-01: Adattamento al Ruolo — 32 criteri, ±4%, 92% — ATTIVO
  - MOD-02: Analisi del Rischio — 58 criteri, ±2%, 96% — CRITICO (dot rosso pulsante)
  - MOD-03: Output Decisionale — 38 criteri, ±3%, 94% — ATTIVO

### [6] COME FUNZIONA / PROCESSO (#come-funziona)
- **Eyebrow**: PROCESSO OPERATIVO / MOD.PROC-03
- **Headline**: "Quattro fasi. Nessuna variabile libera."
- **4 Step**:
  1. INPUT — Allineamento iniziale (2–4h) — "Definiamo ruolo, contesto e livello di rischio della decisione."
  2. ANALISI — Valutazione del candidato (6–8h) — "Analizziamo come il candidato pensa, decide e reagisce sotto pressione."
  3. VERIFICA — Verifica operativa (12–24h) — "Simulazione o scenario reale per osservare comportamento e priorità."
  4. OUTPUT — Sintesi decisionale (24–48h) — "Output chiaro con rischi, compatibilità e raccomandazione finale."
- **Blocco supervisione umana** (sotto i 4 step): dot verde pulsante + "SUPERVISIONE UMANA ATTIVA" + "Analisi condotta da mental coach aziendale senior"

### [7] OUTPUT (#output)
- **Eyebrow**: OUTPUT DECISIONALE / MOD.OUT-04
- **Headline**: "Non un report. Una decisione."
- **Clarify**: "Un'analisi strutturata del candidato con evidenza di rischi, compatibilità e comportamento decisionale."
- **Body**: "Ogni decisione è tracciabile, giustificabile e difendibile..."
- **Human note**: "Ogni valutazione è verificata e validata da un analista senior."
- **3 Feature rows**: Accesso nominale e classificato | Integrità crittografica SHA-256 | Archiviazione permanente certificata
- **CTA**: "ATTIVA UNA VALUTAZIONE EXECUTIVE" + "VEDI IL PROCESSO"
- **Report mockup animato** (sx): generazione progressiva con overlay "GENERAZIONE REPORT IN CORSO..." → metriche 87/74/81/34%

### [8] CTA BANNER (sezione decisionale)
- **Eyebrow**: MOMENTO DECISIONALE
- **Headline**: "Non scegli il migliore. Eviti quello sbagliato."
- **Subheadline**: "È qui che una decisione diventa critica."
- **Sfondo**: gradiente deep green-to-black, glow centrale verde, griglia sottile, scanlines
- **NO bottoni** in questa sezione (rimossa intenzionalmente)

### [9] CONTATTI (#contatti)
- **Eyebrow**: CONTATTI / MOD.CONT-05
- **Titolo**: "Contattaci."
- **Subtitle**: "Scrivici per ricevere informazioni sul processo."
- **Form** (2 campi):
  - RUOLO DA COPRIRE (text input, required)
  - LIVELLO DELLA POSIZIONE (select: Operativo / Manageriale / Executive, required)
- **CTA button**: "INVIA RICHIESTA"
- **Comportamento**: click su "INVIA RICHIESTA" apre client email con:
  - To: `decision@ratioapp.co`
  - Subject: `Richiesta valutazione executive`
  - Body pre-compilato con i valori inseriti
- **Aside informazioni**:
  - Email: decision@ratioapp.co
  - Sede: Dubai, UAE
  - Stato: Sistema attivo — accesso limitato
  - Disponibilità: Lun–Ven, 09:00–18:00 CET
  - Risposta media: 8h nelle ore lavorative
  - Note: "Il processo completo viene condiviso dopo il primo confronto."
  - Conformità: GDPR · ISO 27001 · Dati anonimi per default

### [10] FOOTER
- Logo RATIO + descrizione + email + SYS v2.4.1 BUILD 20241114
- Nav links: HOME | CHI SIAMO | COME FUNZIONA | OUTPUT | CONTATTI
- Copyright: © 2025 RATIO — Decision Intelligence. Dubai, UAE.
- Hash: SHA: d4f9c2a1 · CERTIFIED

---

## 4. FILE E STRUTTURA PROGETTO

### Su Genspark (workspace di sviluppo):
```
/ (root)
├── index.html          (41 KB) — pagina IT
├── style.css           (69 KB) — stili condivisi IT + EN
├── main.js             (19 KB) — JS condiviso IT + EN
├── ratio-logo.png      (338 KB) — logo R dorata
├── BRIEF.md            — questo documento
├── GUIDA-TECNICA.md    — guida tecnica deploy
│
└── en/
    └── index.html      (41 KB) — pagina EN
```

### Su Cloudflare Workers (deploy live — struttura FLAT):
```
/ (root live)
├── index.html          → https://ratioapp.co
├── en_index.html       → https://ratioapp.co/en_index.html  ⚠️ NOME DIVERSO
├── style.css
├── main.js
└── ratio-logo.png
```

⚠️ **IMPORTANTE**: Cloudflare non supporta cartelle nell'uploader web.
Il file `en/index.html` su Genspark viene rinominato `en_index.html` prima di caricarlo.

### Path HTML corretti (index.html IT):
```html
<link rel="stylesheet" href="./style.css" />
<img src="./ratio-logo.png" alt="RATIO" class="logo-img" />
<script src="./main.js"></script>
<!-- Switcher lingua -->
IT → ./index.html  |  EN → ./en_index.html
```

### Path HTML corretti (en/index.html EN → en_index.html su Cloudflare):
```html
<link rel="stylesheet" href="../style.css" />  ← su Genspark
<link rel="stylesheet" href="./style.css" />   ← su Cloudflare (stesso livello)
<!-- Switcher lingua -->
IT → ./index.html  |  EN → ./en_index.html
```

### CDN usati:
```html
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@300;400;500;600&display=swap" rel="stylesheet" />
<!-- Font Awesome 6.4.0 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" />
```

---

## 5. DESIGN SYSTEM

### Palette colori (CSS variables in `:root`):

| Variabile | Valore | Uso |
|---|---|---|
| `--black-1` | #060809 | background principale |
| `--black-2` | ~#0D1117 | card background |
| `--black-3` | ~#141920 | input background |
| `--white` | #EEF1F4 | testo principale |
| `--gray-3` | ~#3D4A57 | testo secondario scuro |
| `--gray-4` | ~#5A6A78 | label |
| `--gray-5` | ~#96A4B0 | testo corpo |
| `--green-bright` | #3FD17A | accento verde principale |
| `--green-dim` | ~#152E20 | background verde scuro |
| `--green-glow` | rgba(63,209,122,0.13) | glow verde |
| `--yellow-bright` | #F0C832 | warning/attenzione |
| `--red-bright` | #FF2E2E | critico/rischio |
| `--border-mid` | rgba(255,255,255,0.08) | bordi card |

### Tipografia:
- **Heading**: Inter 900 (display), letter-spacing -0.03em
- **Body**: Inter 400–500, 14–15px, line-height 1.75
- **Monospaced**: JetBrains Mono, usata per codici, hash, timestamp, label tecniche
- **Eyebrow/label**: JetBrains Mono, 8–10px, uppercase, letter-spacing 0.1em

### Border radius: 3px / 5px / 8px
### Easing: `cubic-bezier(0.16, 1, 0.3, 1)` — variabile `--ease-cin`

---

## 6. JAVASCRIPT (main.js) — FUNZIONI PRINCIPALI

| Funzione | Descrizione |
|---|---|
| `initBoot()` | Avvia boot overlay con log animato, barra progresso, poi rimuove overlay |
| `initNav()` | Navbar: scroll hide/show, active section highlight, progress bar |
| `initReveal()` | IntersectionObserver per animazioni fade-up/fade-right on scroll |
| `initHeroPanel()` | Animazione sequenziale righe del panel assessment (hero dx) |
| `initReportScene()` | Cinematic: overlay generazione + reveal progressivo righe report |
| `initContactForm()` | Validazione form contatti + apertura mailto con valori pre-compilati |
| `initLiveClock()` | Aggiorna timestamp in tempo reale sugli elementi `.panel-ts` |
| `initCounters()` | Animazione contatori numerici (46%, 3.2×, 4×) on scroll |
| `initMobileNav()` | Toggle menu hamburger su mobile |

### Comportamento form (IMPORTANTE):
Il form NON invia dati a un server. Al click su "INVIA RICHIESTA":
1. Valida i 2 campi required
2. Legge i valori di `#cf-ruolo` e `#cf-livello`
3. Costruisce URL mailto:
```
mailto:decision@ratioapp.co
  ?subject=Richiesta%20valutazione%20executive
  &body=Ruolo%20da%20coprire:%20[VALORE]%0A%0ALivello%20della%20posizione:%20[VALORE]%0A%0AContesto:
```
4. Apre client email con `window.location.href`

---

## 7. DEPLOY — CONFIGURAZIONE CLOUDFLARE

| Campo | Valore |
|---|---|
| **Piattaforma** | Cloudflare Workers (static assets) |
| **Worker name** | ratio |
| **Account** | Servizitelematici1@gmail.com |
| **URL worker** | ratio.servizitelematici1.workers.dev |
| **Custom domain** | ratioapp.co |
| **Nameserver** | bailey.ns.cloudflare.com / gannon.ns.cloudflare.com |
| **Registrar** | Namecheap (nameserver → Custom DNS → Cloudflare) |
| **SSL** | Automatico Cloudflare (HTTPS attivo) |

### Per aggiornare il sito live:
1. Modifica i file su Genspark
2. Scarica da Genspark: `index.html`, `style.css`, `main.js`, `ratio-logo.png`
3. Scarica `en/index.html` da Genspark e **rinominalo** `en_index.html`
4. Vai su **dash.cloudflare.com → Workers & Pages → ratio**
5. Clicca **"New deployment"**
6. Carica tutti e 5 i file:
   - `index.html`
   - `en_index.html`
   - `style.css`
   - `main.js`
   - `ratio-logo.png`
7. Clicca **Deploy** e verifica su https://ratioapp.co

---

## 8. REGOLE GLOBALI (NON VIOLARE MAI)

1. **Non cambiare il layout** — struttura a sezioni, grid, spacing calibrati
2. **Non cambiare la tipografia** — Inter + JetBrains Mono, pesi e dimensioni definiti
3. **Non aggiungere elementi non richiesti** — ogni aggiunta deve essere esplicita
4. **Non usare tono promozionale** — solo autorevole, tecnico, implicito
5. **Non mostrare profili personali** — presenza umana senior implicita, non nominata
6. **Non rimuovere la supervisione umana** — blocco "SUPERVISIONE UMANA ATTIVA" sempre visibile
7. **Mantenere il sistema di animazioni** — boot, reveal scroll, panel, report cinematic
8. **Percorso asset SEMPRE con `./`** — `./style.css`, `./main.js`, `./ratio-logo.png`

---

## 9. MODIFICHE STORICHE (log completo)

| Data | Modifica |
|---|---|
| Apr 2025 | Creazione sito one-page RATIO da zero |
| Apr 2025 | Sezione processo: 4 fasi con testi definitivi |
| Apr 2025 | Blocco supervisione umana: dot verde + label + descrizione |
| Apr 2025 | CTA banner: headline "Non scegli il migliore. Eviti quello sbagliato." |
| Apr 2025 | CTA banner: rimossi bottoni, solo headline + subheadline |
| Apr 2025 | Contact form: semplificato a 2 campi + mailto action |
| Apr 2025 | Output section: aggiunta riga "Ogni valutazione è verificata e validata da un analista senior." |
| Apr 2025 | Logo navbar: sostituito testo "RATIO" con immagine ratio-logo.png (R dorata) |
| Apr 2025 | Fix deploy: path flat root (./style.css, ./main.js, ./ratio-logo.png) |
| Apr 2025 | Deploy su Cloudflare Workers + dominio ratioapp.co collegato |
| Apr 2025 | Sito reso **bilingue IT + EN** con language switcher in navbar |
| Apr 2025 | Versione EN: traduzione professionale board-level di tutti i contenuti |
| Apr 2025 | main.js aggiornato con i18n auto-detect (data-lang attribute) |
| Apr 2025 | Deploy bilingue: en/index.html rinominato en_index.html per Cloudflare flat upload |

---

## 10. LANGUAGE SWITCHER — DETTAGLI TECNICI

### Stile CSS (in style.css):
- Classe `.lang-switcher` — flex, gap 2px, margin-left 8px
- Classe `.lang-btn` — mono 10px, border transparent, hover bianco
- Classe `.lang-btn.active` — verde bright, border verde, background verde dim
- Classe `.lang-sep` — linea verticale 1px grigia

### HTML navbar (uguale in entrambe le versioni):
```html
<div class="lang-switcher">
  <a href="./index.html" class="lang-btn [active se IT]">IT</a>
  <span class="lang-sep"></span>
  <a href="./en_index.html" class="lang-btn [active se EN]">EN</a>
</div>
```

### Rilevamento lingua in JS:
```html
<html lang="it" data-lang="it">  ← IT
<html lang="en" data-lang="en">  ← EN
```
Il JS legge `document.documentElement.getAttribute('data-lang')` e adatta messaggi form e mailto.

---

## 11. PROSSIMI STEP CONSIGLIATI

- [ ] Aggiungere Google Analytics o Cloudflare Web Analytics (gratuito)
- [ ] Configurare email professionale `decision@ratioapp.co` con Google Workspace
- [ ] Aggiungere `www.ratioapp.co` come custom domain aggiuntivo sul Worker
- [ ] Ottimizzare meta tag SEO (description, og:image, og:title per IT e EN)
- [ ] Aggiungere favicon (versione piccola della R dorata)
- [ ] Valutare URL pulito per EN: `ratioapp.co/en` invece di `ratioapp.co/en_index.html`

---

*BRIEF aggiornato il 23 Aprile 2025 — Versione 2.0*
*Aggiunto: versione bilingue IT + EN, struttura deploy Cloudflare, language switcher.*
*Per qualsiasi modifica futura: carica questo file e di' "leggi BRIEF.md e riparti da qui".*
