# RATIO — Sistema Decisionale Executive

## 📋 Panoramica

RATIO è un sito web one-page per una piattaforma di decision intelligence premium nel campo della selezione executive. Il design è stato concepito come un sistema analitico interno riservato — dark, tecnico, stratificato — con l'estetica di una piattaforma ad alto livello utilizzata da analisti e top executive.

## 🎯 Obiettivo del Progetto

Trasformare una landing minimal in una **piattaforma decision intelligence premium**, percepita come:
- Un sistema interno riservato
- Un tool usato da top executive e analisti
- Un'interfaccia con profondità, layer e densità informativa

## ✅ Features Implementate

### Struttura delle Sezioni (invariata rispetto al design originale)
- **Hero** — Layout split 60/40: headline massiva + pannello assessment preview
- **Contesto Operativo** — 3 data cards con metriche critiche
- **Architettura del Sistema** — 3 moduli analitici con features e metriche
- **Processo Operativo** — Timeline a 4 step con output evidenziato
- **Output Decisionale** — Report mockup classificato + copy + CTA
- **CTA Banner** — Banner verde con accesso enterprise
- **Contatti** — Form validato + sidebar info
- **Footer** — Info sistema, navigazione, hash di certificazione

### Profondità Visiva & Atmosfera
- Grid tecnica a sfondo fisso + scanlines
- Texture noise SVG su tutto il body
- Layer radial gradient nella hero
- Overlay geometrici e transizioni tra sezioni
- Subtle grain per evitare flat black

### Hero Right Panel (Dashboard)
- Campi tabellari con field-label + field-value
- 4 metriche animate con barre, delta, threshold
- Raccomandazione con dot colorato
- Footer con timestamp live, hash SHA, badge CONFIDENTIAL
- Stato: RISERVATO (badge rosso)

### Data Visual Enhancement
- Barre metriche animate via IntersectionObserver
- Micro-bars animate on hover nelle data cards
- Numeri con counter animation (da 0 al valore target)
- Ghost bars + segmentazione sulle metric-bar-track
- Delta indicators (↑ ↔) colorati

### Typography Hierarchy
- Eyebrow labels uppercase con codice modulo
- Section headline massive
- Secondary labels, annotations, micro-text
- Font mono per tutti i valori tecnici (JetBrains Mono)

### Output Section
- Report mockup con struttura da documento classificato
- Metadata: ref, data, candidato anonimizzato, revisore, versione modello
- Metriche con barre animate
- Note analista, hash SHA-256, timestamp
- Feature icons con hover states tecnici

### Interazioni
- Scroll progress bar nella nav
- Active nav link tracking via scroll
- Typing effect sull'eyebrow dell'hero
- Cursor trail verde (solo desktop)
- Grid parallax lieve con mouse
- Module cards: sequential feature highlight on hover
- Metric rows: brightness pulse on hover
- Panel/report field rows: highlight on hover
- Micro-bars: animazione casuale on hover
- Form: validazione real-time + submit simulato con spinner

### Form Contatti
- Validazione campi obbligatori
- Validazione formato email
- Feedback errore per campo
- Messaggio di successo dopo submit
- Loading state con spinner

## 🗂️ Struttura File

```
index.html          — Pagina principale
css/
  style.css         — Tutti gli stili (dark dashboard premium)
js/
  main.js           — Micro-interazioni e animazioni tecniche
```

## 🔗 Navigazione (URI)

| Sezione | Ancora |
|---------|--------|
| Home / Hero | `#home` |
| Chi Siamo / Contesto | `#chi-siamo` |
| Come Funziona / Processo | `#come-funziona` |
| Output | `#output` |
| Contatti | `#contatti` |

## 🎨 Design System

### Palette
| Token | Valore | Uso |
|-------|--------|-----|
| `--black` | `#080A0D` | Background principale |
| `--green-bright` | `#4DAB7A` | Accento positivo, CTA |
| `--yellow-bright` | `#E2BB3A` | Warning, attenzione |
| `--red-bright` | `#D04040` | Rischio, critico |
| `--white` | `#F0F2F5` | Testo principale |

### Font
- **Inter** — Headlines, body, UI
- **JetBrains Mono** — Dati tecnici, codici, timestamp, metriche

## 📚 Knowledge Base RATIO — Insights (9 Articoli IT + EN)

| # | Titolo IT | Titolo EN | Data | Cover |
|---|-----------|-----------|------|-------|
| 1 | insight-1.html | en_insight-1.html | 2026 | cover-1 |
| 2 | insight-2.html | en_insight-2.html | 2026 | cover-2 |
| 3 | insight-3.html | en_insight-3.html | 2026 | cover-3 |
| 4 | insight-4.html | en_insight-4.html | 2026 | cover-4 |
| 5 | insight-5.html | en_insight-5.html | 2026 | cover-5 |
| 6 | insight-6.html | en_insight-6.html | 2026-07-01 | cover-6 |
| 7 | insight-7.html | en_insight-7.html | 2026-07-06 | cover-7 |
| 8 | insight-8.html | en_insight-8.html | 2026-07-22 | cover-8 |
| 9 | insight-9.html | en_insight-9.html | 2026-08-08 | cover-9 |

### Insight 9 — Elementi Speciali
- **Signal Flow Diagram** — 4 step (Segnale → Interpretazione → Problema → Decisione) con punto di vulnerabilità evidenziato in ambra
- **Problem Frame Test Table** — 5 domande × 2 colonne (framework proprietario RATIO)
- **Due Architetture Decisionali** — comparativo a 2 colonne (Approccio A / B)
- **Decision Stress Test Box** — 6 domande con chiusura verde
- **Founder Quote** — Cristiano Ludovisi
- **Nessuna statistica inventata** — solo framework qualitativi RATIO

## ⚠️ Features Non Ancora Implementate

- Backend per form (attualmente simulato)
- CMS per aggiornamento contenuti
- Sistema autenticazione per area riservata
- Analytics/tracking avanzato

## 🚀 Prossimi Passi Consigliati

1. Collegare il form a un backend reale (es. Formspree, Netlify Forms)
2. Aggiungere Insight #10 quando disponibile
3. Implementare una sezione casi studio con report anonimizzati
4. Aggiungere search/filter nella pagina insights
5. Ottimizzare performance (font preload, lazy loading immagini)

## 📡 Deploy

Per pubblicare il sito, vai alla scheda **Publish** e premi il pulsante di pubblicazione.
