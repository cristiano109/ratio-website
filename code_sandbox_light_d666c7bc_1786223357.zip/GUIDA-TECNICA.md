# RATIO — GUIDA TECNICA COMPLETA
> Documento di riferimento per la gestione tecnica del sito ratioapp.co
> Generato il 23 Aprile 2025

---

## 1. DOVE È OSPITATO IL SITO

Il sito è ospitato su **Cloudflare Workers** — infrastruttura di Cloudflare, NON sui server di Genspark.

I file sono stati caricati manualmente su Cloudflare. Cloudflare li serve globalmente tramite la sua CDN (edge network presente in oltre 200 città nel mondo).

---

## 2. DOVE SONO I FILE FISICAMENTE

I file esistono in **due posti separati e indipendenti**:

| Posizione | File presenti | Stato |
|---|---|---|
| **Genspark** (editor/workspace) | index.html, style.css, main.js, ratio-logo.png | ✅ Versione di lavoro |
| **Cloudflare Workers** (live) | index.html, style.css, main.js, ratio-logo.png | ✅ Versione pubblica live |

⚠️ I due set di file sono **indipendenti**.
Una modifica su Genspark **non aggiorna automaticamente** Cloudflare.

---

## 3. SEI ANCORA CONNESSO A GENSPARK?

**No. Non esiste connessione automatica.**

- **Genspark** = il tuo editor e workspace di sviluppo
- **Cloudflare** = il tuo hosting pubblico

Non comunicano tra loro. Devi sincronizzarli **manualmente** ogni volta che aggiorni il sito.

---

## 4. DOVE FARE LE MODIFICHE

**Sempre su Genspark prima**, poi esporti su Cloudflare.

| Tipo di modifica | File da modificare |
|---|---|
| Testi, copy, sezioni HTML | `index.html` |
| Stili, colori, layout, spaziature | `style.css` |
| Animazioni, form, comportamento JS | `main.js` |
| Logo o immagini | Carica nuovo file su Genspark |

> ⚠️ **Non modificare mai direttamente su Cloudflare.**
> Non ha un editor visuale e perderesti il backup su Genspark.

---

## 5. COME AGGIORNARE IL SITO LIVE DOPO UNA MODIFICA

Ogni volta che aggiorni qualcosa su Genspark, segui questi passi:

```
STEP 1 — Modifica su Genspark
  → Chiedi all'assistente di modificare i file
  → Verifica in anteprima che tutto funzioni correttamente

STEP 2 — Scarica i file aggiornati
  → Genspark → "Esplora file"
  → Scarica: index.html, style.css, main.js
  → (solo se modificato) ratio-logo.png

STEP 3 — Vai su Cloudflare
  → Apri https://dash.cloudflare.com
  → Vai su: Workers & Pages → ratio
  → Clicca "New deployment" (in alto a destra)

STEP 4 — Carica i file
  → Drag & drop dei file scaricati
  → Verifica che siano presenti tutti e 4:
     ✅ index.html
     ✅ style.css
     ✅ main.js
     ✅ ratio-logo.png

STEP 5 — Deploy
  → Clicca "Deploy"
  → Attendi 10–30 secondi
  → Apri https://ratioapp.co in modalità privata (Ctrl+Shift+N)
     per verificare che l'aggiornamento sia andato a buon fine
```

---

## 6. PROVIDER E SERVIZI CONNESSI

| Provider | Ruolo | URL |
|---|---|---|
| **Cloudflare Workers** | Hosting dei file statici + CDN globale | dash.cloudflare.com |
| **Cloudflare DNS** | Gestione zona DNS del dominio ratioapp.co | dash.cloudflare.com |
| **Namecheap** | Registrar del dominio (dove è stato acquistato) | namecheap.com |
| **Genspark** | Editor/workspace per lo sviluppo — NON è hosting | genspark.ai |

---

## 7. COME È CONNESSO IL DOMINIO

```
NAMECHEAP (registrar del dominio)
    └─ Nameserver impostati su Cloudflare:
       ├── bailey.ns.cloudflare.com
       └── gannon.ns.cloudflare.com
            ↓
CLOUDFLARE DNS ZONE (ratioapp.co)
    └─ Record DNS: Worker route ratioapp.co → Worker "ratio"
    └─ SSL automatico (certificato HTTPS gratuito)
            ↓
CLOUDFLARE WORKER "ratio"
    └─ Serve i file statici del sito
            ↓
https://ratioapp.co  →  Il tuo sito live
```

Il dominio `ratioapp.co` è **completamente delegato a Cloudflare** tramite nameserver.
Cloudflare gestisce DNS, SSL/HTTPS e routing verso il Worker.

---

## 8. PROCESSO AGGIORNAMENTO SICURO — CHECKLIST

Prima di ogni aggiornamento, segui questa checklist:

- [ ] Ho testato le modifiche in anteprima su Genspark
- [ ] Ho scaricato TUTTI e 4 i file aggiornati
- [ ] Ho aperto dash.cloudflare.com e sono nel Worker "ratio"
- [ ] Ho caricato tutti i file nel nuovo deployment
- [ ] Ho cliccato Deploy e aspettato la conferma
- [ ] Ho verificato il sito live in una finestra privata del browser
- [ ] Ho salvato una copia locale dei file sul mio computer

---

## 9. RISCHI E COME EVITARLI

| Scenario | Livello rischio | Soluzione |
|---|---|---|
| Carichi file sbagliati su Cloudflare | ⚠️ Medio | Cloudflare mantiene le versioni precedenti → rollback da "Deployments" |
| Chiudi la chat Genspark senza salvare | ⚠️ Alto | I file Genspark rimangono nel progetto, ma il contesto chat si perde |
| Perdi accesso a Genspark | 🔴 Alto | Hai BRIEF.md e i file scaricati → puoi ricostruire tutto |
| Cloudflare cancella il Worker | 🔴 Molto basso | Tieni sempre una copia ZIP locale di tutti i file |

### Come fare rollback su Cloudflare (se qualcosa va storto):
1. Vai su `dash.cloudflare.com`
2. Apri `Workers & Pages → ratio → Deployments`
3. Trova la versione precedente funzionante
4. Clicca `...` → `Promote to production`
5. Il sito torna alla versione precedente in pochi secondi

---

## 10. ARCHITETTURA COMPLETA DEL SISTEMA

```
┌─────────────────────────────────────────────────────────┐
│                     UTENTE FINALE                        │
│                 https://ratioapp.co                      │
└──────────────────────────┬──────────────────────────────┘
                           │ HTTPS (SSL automatico gratuito)
┌──────────────────────────▼──────────────────────────────┐
│                   CLOUDFLARE CDN                         │
│           Edge network globale (200+ città)              │
│   DNS Zone: ratioapp.co                                  │
│   Worker route: ratioapp.co → Worker "ratio"             │
└──────────────────────────┬──────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────┐
│              CLOUDFLARE WORKER "ratio"                   │
│   Account: Servizitelematici1@gmail.com                  │
│   URL worker: ratio.servizitelematici1.workers.dev       │
│   Custom domain: ratioapp.co                             │
│                                                          │
│   File serviti:                                          │
│   ├── index.html       (struttura HTML della pagina)     │
│   ├── style.css        (design, colori, layout)          │
│   ├── main.js          (animazioni, form, logica)        │
│   └── ratio-logo.png   (logo R dorata — 338 KB)          │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│               NAMECHEAP (registrar dominio)              │
│   Dominio acquistato: ratioapp.co                        │
│   Nameserver → bailey/gannon.ns.cloudflare.com           │
│   (il dominio è delegato completamente a Cloudflare)     │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│            GENSPARK (editor — NON è hosting)             │
│   Versione di lavoro dei file:                           │
│   ├── index.html                                         │
│   ├── style.css                                          │
│   ├── main.js                                            │
│   ├── ratio-logo.png                                     │
│   ├── BRIEF.md         (documento progetto completo)     │
│   └── GUIDA-TECNICA.md (questo documento)                │
│                                                          │
│   ⚠️ NON connesso automaticamente a Cloudflare           │
│   → Sincronizzazione MANUALE ad ogni aggiornamento       │
└─────────────────────────────────────────────────────────┘
```

---

## 11. RIEPILOGO IN UNA FRASE

> **Genspark è il tuo studio di progettazione.
> Cloudflare è la tua fabbrica e il tuo negozio.
> Ogni volta che progetti qualcosa di nuovo, devi portarlo manualmente dalla fabbrica al negozio.**

---

## 12. RIFERIMENTI RAPIDI

| Cosa fare | Dove andare |
|---|---|
| Modificare il sito | Genspark (questa sessione) |
| Vedere il sito live | https://ratioapp.co |
| Gestire il deploy | https://dash.cloudflare.com → Workers & Pages → ratio |
| Gestire DNS e dominio | https://dash.cloudflare.com → Domains → ratioapp.co → DNS |
| Gestire il registrar | https://namecheap.com → Domain List → ratioapp.co |
| Contatto operativo sito | decision@ratioapp.co |
| Documento progetto completo | BRIEF.md (nella cartella Genspark) |

---

## 13. CREDENZIALI E ACCOUNT (conserva in modo sicuro)

| Servizio | Account | Note |
|---|---|---|
| **Cloudflare** | Servizitelematici1@gmail.com | Gestisce hosting e DNS |
| **Namecheap** | (account con cui hai acquistato ratioapp.co) | Solo per rinnovo dominio |
| **Genspark** | (account attuale) | Editor del sito |

> ⚠️ **Conserva queste informazioni in un posto sicuro.**
> Senza accesso a Cloudflare non puoi aggiornare il sito live.
> Senza accesso a Namecheap non puoi rinnovare il dominio (scade Apr 2026).

---

*GUIDA TECNICA generata il 23 Aprile 2025 — Versione 1.0*
*Documento di supporto a BRIEF.md*
