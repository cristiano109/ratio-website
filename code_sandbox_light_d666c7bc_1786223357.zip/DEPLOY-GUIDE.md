# 🚀 DEPLOY GUIDE — ratioapp.co su Cloudflare Workers

## Stato attuale (13 giugno 2026)

| Componente | Stato |
|---|---|
| Sito live | ✅ Stabile su rollback `2b801645` |
| GitHub repo | ✅ `cristiano109/ratio-website` (branch `main`) |
| GitHub → Cloudflare | ⚠️ Build fallisce — fix in corso |
| sitemap.xml | ✅ Live + Google Search Console |
| robots.txt | ✅ Live |
| Fix mobile insight | ✅ Pronto, in attesa di deploy |

---

## ❌ PROBLEMA: Build GitHub fallisce

**Causa**: il comando `npx wrangler deploy` non trova `wrangler.toml`  
**Fix applicato**: creato `wrangler.toml` nella root del repo

---

## ✅ AZIONI DA FARE (in ordine)

### 1. Fix Deploy Command in Cloudflare (PRIORITÀ MASSIMA)

1. Vai su `dash.cloudflare.com`
2. Workers & Pages → **ratio** → **Settings** → sezione **Build**
3. Clicca la **matita ✏️** accanto a "Build configuration"
4. Cambia il campo **Deploy command** da:
   ```
   npx wrangler deploy
   ```
   a:
   ```
   npx wrangler deploy --assets .
   ```
5. Salva

> ⚠️ **Perché questo fix?**  
> `npx wrangler deploy` richiede un `wrangler.toml`. Abbiamo aggiunto il `wrangler.toml` al repo, MA il comando `--assets .` è anche più robusto per siti statici puri senza Worker script.

---

### 2. Committare i file modificati su GitHub

File da includere nel prossimo commit:

```
✅ wrangler.toml              ← NUOVO — risolve il build failure
✅ style-2.css                ← Fix mobile reveal-block
✅ insights.css               ← Media query mobile article layout
✅ insight-1.html             ← Rimossa classe reveal-block da article-content
✅ insight-2.html             ← Rimossa classe reveal-block da article-content
✅ insight-3.html             ← Rimossa classe reveal-block da article-content
✅ en_insight-1.html          ← Rimossa classe reveal-block da article-content
✅ en_insight-2.html          ← Rimossa classe reveal-block da article-content
✅ en_insight-3.html          ← Rimossa classe reveal-block da article-content
✅ en/insight-1.html          ← Rimossa classe reveal-block da article-content
✅ en/insight-2.html          ← Rimossa classe reveal-block da article-content
✅ en/insight-3.html          ← Rimossa classe reveal-block da article-content
✅ sitemap.xml                ← Già live (no modifiche)
✅ robots.txt                 ← Già live (no modifiche)
❌ _worker.js                 ← ELIMINATO — causava crash
❌ _redirects                 ← NON commitare — sintassi Pages, non Workers
```

**Comando Git:**
```bash
git add wrangler.toml style-2.css insights.css
git add insight-1.html insight-2.html insight-3.html
git add en_insight-1.html en_insight-2.html en_insight-3.html
git add en/insight-1.html en/insight-2.html en/insight-3.html
git rm _worker.js  # rimuove dal tracking Git
git commit -m "Fix: mobile reveal-block bug + wrangler.toml per deploy Workers"
git push origin main
```

---

### 3. Verificare il build

Dopo il push, vai su:
`dash.cloudflare.com` → Workers & Pages → ratio → **Deployments**

Il build deve completarsi senza errori. Se vedi ancora errori, controlla i log cliccando "View build".

---

## ⚠️ NOTE SUI FILE CRITICI

| File | Stato | Note |
|---|---|---|
| `_worker.js` | ✅ RIPRISTINATO (v2 — luglio 2025) | Versione minimale: intercetta SOLO sitemap.xml e robots.txt per impostare Content-Type corretto. Tutto il resto passa tramite `env.ASSETS.fetch()`. NON contiene routing custom. |
| `wrangler.toml` | ✅ AGGIORNATO | Aggiunto `binding = "ASSETS"` per consentire al Worker di accedere agli asset statici via `env.ASSETS` |
| `_redirects` | ❌ NON USARE | Sintassi Cloudflare Pages — non funziona su Workers |
| `_headers` | ⚠️ IGNORATO | Funziona solo su Cloudflare Pages, non su Workers. Non eliminarlo ma non ha effetto. |

### Perché _worker.js v2 è sicuro (a differenza della v1)
La v1 crashava perché implementava routing custom che interferiva con la risoluzione degli asset.
La v2 usa `env.ASSETS.fetch(request)` — delega tutto a Cloudflare, modifica solo gli header di risposta per sitemap.xml e robots.txt.

### Rollback di emergenza
Se il sito va giù dopo il deploy:
1. `dash.cloudflare.com` → Workers & Pages → ratio → **Deployments**
2. Trova la versione stabile precedente
3. Clicca **"Rollback to this deployment"**

---

## 📋 ROLLBACK DI EMERGENZA

Se il sito va giù dopo un deploy:
1. `dash.cloudflare.com` → Workers & Pages → ratio → **Deployments**
2. Trova la versione stabile `2b801645`
3. Clicca "Rollback to this deployment"

---

## 🔍 VERIFICA POST-DEPLOY

Dopo deploy riuscito, verificare:

- [ ] `https://ratioapp.co/insight-1.html` da mobile → contenuto visibile
- [ ] `https://ratioapp.co/en_insight-1.html` da mobile → contenuto visibile  
- [ ] `https://ratioapp.co/sitemap.xml` → risponde 200
- [ ] `https://ratioapp.co/robots.txt` → risponde 200
- [ ] Canonical tags: `view-source:https://ratioapp.co` → nessun `www.`

---

## 🏗️ ARCHITETTURA HOSTING

```
GitHub (cristiano109/ratio-website)
    ↓ push to main
Cloudflare Workers Build
    ↓ npx wrangler deploy --assets .
ratioapp.co (Cloudflare Workers Static Assets)
```

**NON è Cloudflare Pages** — è Cloudflare Workers con static assets.  
Differenza critica: `_redirects` non funziona, `_worker.js` sovrascrive il routing.

---

## 📊 STATO SEO

| Task | Stato |
|---|---|
| Canonical tags (no www) | ✅ Tutti i 10 HTML |
| hreflang assoluti | ✅ Tutti i 10 HTML |
| OG tags e JSON-LD | ✅ Tutti i 10 HTML |
| sitemap.xml (10 URL, hreflang IT/EN) | ✅ Live |
| robots.txt (con Sitemap direttiva) | ✅ Live |
| Google Search Console | ✅ 10 pagine rilevate, stato "Riuscita" |
| www→no-www redirect | ⏳ Da implementare (tramite Cloudflare Dashboard DNS) |
